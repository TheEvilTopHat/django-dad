from django.apps import AppConfig


class DadJokeConfig(AppConfig):
    name = 'django-dad'
